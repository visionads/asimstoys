<div class="text-center">
    2016 &copy; Asims Toys by Seo & Website by VisionsAds
    <a href="#" class="go-top">
        <i class="icon-angle-up"></i>
    </a>
</div>